from __future__ import print_function
import numpy as np
import tensorflow as tf
import ops as my_ops
import os


class Ico:
    def __init__(self, sess, args):
        self.sess = sess

